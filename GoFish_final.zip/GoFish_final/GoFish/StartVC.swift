//
//  StartVC.swift
//  GoFish
//
//  Created by Guru Karthik on 09/03/21.
//

import Foundation
import UIKit

class StartVC: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate {
    
    @IBOutlet weak var playerPicker: UIPickerView!
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        if segue.destination is ViewController {
            let vc = segue.destination as? ViewController
            vc!.numOfPlayers = numP
        }
    }
//    @IBAction func btnPlay(_ sender: UIButton) {
//        let vc = ViewController()
//        
//        navigationController?.pushViewController(vc, animated: true)
//    }
    var numP:Int = 2
    let numOfPlayers = [2,3,4]
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        3
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return String(numOfPlayers[row])
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        numP = numOfPlayers[row]
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        playerPicker.dataSource = self
        playerPicker.delegate = self
    }
     
}
