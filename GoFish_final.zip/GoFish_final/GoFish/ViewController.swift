//
//  ViewController.swift
//  GoFish
//
//  Created by Sai Krishna on 06/03/21.
//

//framework which provides the classes, functons needed for user interactions, user interface and others
import UIKit
import Foundation
//class which holds the all the attributes needed for the player
class Player{
    //array of cards the player has
    var cards:[String] = []
    //points awarded to the player
    var points:Int = 0
    //count of each type of card the user has
    var count2: Int = 0
    var count3: Int = 0
    var count4: Int = 0
    var count5: Int = 0
    var count6: Int = 0
    var count7: Int = 0
    var count8: Int = 0
    var count9: Int = 0
    var count10: Int = 0
    var countK: Int = 0
    var countQ: Int = 0
    var countJ: Int = 0
    var countA: Int = 0
    //parameter to check if player is user or computer
    var oponnents:[Player] = []
    var playerIsHuman:Bool = false
    var playerName:String = ""
    //unused parameter
    var nextPlayer:Player? = nil
    //placer icon
    var icon:UIButton? = nil
    var isOutOfGame:Bool = false
    var model:Model!
    var exposedCards:[String] = []
}

class ViewController: UIViewController {

//player 4 button
  //
    
    var models:[Model]!
    
    @IBAction func P4Btn(_ sender: UIButton) {
        giver = players[3]
        //set images/icon for each player
        players[3].icon?.setBackgroundImage(UIImage(systemName: "person.circle.fill"), for: .normal)
        players[2].icon?.setBackgroundImage(UIImage(systemName: "person.circle"), for: .normal)
        players[1].icon?.setBackgroundImage(UIImage(systemName: "person.circle"), for: .normal)
        //hide the ASK button
        AskBtnOutlet.isHidden = false
    }
//player 3 button
    @IBAction func P3Btn(_ sender: UIButton) {
        giver = players[2]
        players[2].icon?.setBackgroundImage(UIImage(systemName: "person.circle.fill"), for: .normal)
        players[1].icon?.setBackgroundImage(UIImage(systemName: "person.circle"), for: .normal)
        AskBtnOutlet.isHidden = false
    }

    //player 2 button
    @IBAction func P2Btn(_ sender: UIButton) {
        giver = players[1]
        
        for p in 1..<players.count{
            players[p].icon?.setBackgroundImage(UIImage(systemName: "person.circle"), for: .normal)
        }
        players[1].icon?.setBackgroundImage(UIImage(systemName: "person.circle.fill"), for: .normal)
        AskBtnOutlet.isHidden = false
    }
    
    //player 1 button
    @IBOutlet weak var P1BtnOutlet: UIButton!
    @IBOutlet weak var P2BtnOutlet: UIButton!
    @IBOutlet weak var P3BtnOutlet: UIButton!
    @IBOutlet weak var P4BtnOutlet: UIButton!
    @IBOutlet weak var player3Lbl: UILabel!
    @IBOutlet weak var player4Lbl: UILabel!
    
    @IBOutlet weak var deckCountLbl: UILabel!
    @IBOutlet weak var selectCardLbl: UILabel!
    @IBOutlet weak var goFishBtnOutlet: UIButton!
    @IBOutlet weak var userPoints: UILabel!
    @IBOutlet weak var P2points: UILabel!
    @IBOutlet weak var P3points: UILabel!
    @IBOutlet weak var P4points: UILabel!
    //function for GoFish button
    @IBAction func btnGoFish(_ sender: UIButton) {
        goFishBtnOutlet.isHidden = true
        //pick random card from deck
        let randomCard = deck.randomElement()!
        deckOutletBtn.setImage(UIImage(named: randomCard), for: .normal)
        deck.remove(at: deck.firstIndex(of: randomCard)!)
        //add card to player's hand
        asker.cards.append(randomCard)
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0){ [self] in
            deckOutletBtn.setImage(UIImage(named: "red_back"), for: .normal)
            asker.icon?.setBackgroundImage(UIImage(systemName: "person.circle"), for: .normal)
            giver.icon?.setBackgroundImage(UIImage(systemName: "person.circle"), for: .normal)
            //check for 4 card set
            removeBooksFromHand()
            //reset the display of each player's hand
            self.setupDisplay()
//            self.asker = players[0]
//            self.giver = players[1]
            //continue the play
            self.asker = asker.nextPlayer
            userAskedCard = getMultipleCard(asker: self.asker)
            if(userAskedCard == ""){
            var foundOpponent = false
            outerLoop: for card in self.asker.cards{
            let a = String(Array(card)[0])
            for i in 0..<asker.oponnents.count{
                for expCard in self.asker.oponnents[i].exposedCards{
                    if(expCard.hasPrefix(a)){
                        foundOpponent = true
                        self.giver = self.asker.oponnents[i]
                        userAskedCard = expCard
                        break outerLoop
                        }
                    }
                }
            }
            if(!foundOpponent){
                self.giver = self.asker.oponnents.randomElement()
                if(self.giver.cards.count > 0){
                    self.userAskedCard = self.asker.cards.randomElement()!
                }
                else{
                    endGame()
                }
            }
        }
            else{
                self.giver = self.asker.oponnents.randomElement()
            }
//            giver = asker.oponnents.randomElement()
            self.startPlay(asker1: asker, giver1: giver)
        }
    }
    
    //function for ASK button
    @IBAction func btnAsk(_ sender: UIButton) {
    //        giver = players[1]
    //        asker = players[0]
            //respond to card requested by the requesting player
            respondToCardRequest(requestedCard: userAskedCard, asker: asker, giver: giver)
    //        startPlay(asker1: asker, giver1: giver)
            AskBtnOutlet.isHidden = true
            P2BtnOutlet.isUserInteractionEnabled = true
            P3BtnOutlet.isUserInteractionEnabled = true
            P4BtnOutlet.isUserInteractionEnabled = true
    //        setupDisplay()
            
            
    }
    
    @IBOutlet weak var deckOutletBtn: UIButton!
    //unused
    @IBAction func btnDeck(_ sender: UIButton) {
        pickFromDeck(player: players[0])
    }

    @IBOutlet weak var AskBtnOutlet: UIButton!
    @IBOutlet weak var p4SV: UIStackView!
    @IBOutlet weak var p3SV: UIStackView!
    @IBOutlet weak var p2SV: UIStackView!
    @IBOutlet weak var p1SV: UIStackView!
    var giver: Player!
    var asker: Player!
//    var nextPlayer: Player!
    
    var gameNowBegan = false
    
    var userAskedCard: String = ""
    var numOfPlayers:Int = 2
    var deck:[String] = []
    var stacks:[UIStackView] = []
    var plrBtnOutlets:[UIButton] = []
    var pointsLbls:[UILabel] = []
    let stackView:UIStackView = {
        let stack = UIStackView()
        stack.translatesAutoresizingMaskIntoConstraints = false
        return stack
    }()
    var players:[Player] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        goFishBtnOutlet.isHidden = true
        selectCardLbl.isHidden = false
        //add ui elememt stack to stack array
        stacks.append(p1SV)
        stacks.append(p2SV)
        stacks.append(p3SV)
        stacks.append(p4SV)
        AskBtnOutlet.isHidden = true
        
        P1BtnOutlet.isUserInteractionEnabled = false
        P2BtnOutlet.isUserInteractionEnabled = false
        P3BtnOutlet.isUserInteractionEnabled = false
        P4BtnOutlet.isUserInteractionEnabled = false
        
        P3BtnOutlet.isHidden = true
        P4BtnOutlet.isHidden = true
        
        player3Lbl.isHidden = true
        player4Lbl.isHidden = true
        P3points.isHidden = true
        P4points.isHidden = true
        plrBtnOutlets = [P1BtnOutlet, P2BtnOutlet, P3BtnOutlet, P4BtnOutlet]
        pointsLbls = [userPoints, P2points, P3points, P4points]
        deckOutletBtn.isUserInteractionEnabled = false
  
        
        //Filename = what the actr file is called
        //model.loadModel(fileName: "gofish_3")
        //model.loadedModel = "gofish"
        //model.run()
        //deck array
        deck = ["2C", "2D", "2H", "2S", "3C", "3D", "3H", "3S", "4C", "4D", "4H", "4S", "5C", "5D", "5H", "5S", "6C", "6D", "6H", "6S", "7C", "7D", "7H", "7S", "8C", "8D", "8H", "8S", "9C", "9D", "9H", "9S", "BC", "BD", "BH", "BS", "aC", "aD", "aH", "aS", "kC", "kD", "kH", "kS", "qC", "qD", "qH", "qS", "jC", "jD", "jH", "jS" ]
        deck.shuffle()
    
        //set the UI constraints to the player's hand
        p1SV.heightAnchor.constraint(equalToConstant: view.frame.height - 775).isActive = true
        p1SV.widthAnchor.constraint(equalToConstant: view.frame.width - 115).isActive = true
        
        
//        p1SV.translatesAutoresizingMaskIntoConstraints = false
//        p1SV.leadingAnchor.constraint(equalTo: p1ScrollView.leadingAnchor).isActive = true
//        p1SV.trailingAnchor.constraint(equalTo: p1ScrollView.trailingAnchor).isActive = true
//        p1SV.topAnchor.constraint(equalTo: p1ScrollView.topAnchor).isActive = true
//        p1SV.bottomAnchor.constraint(equalTo: p1ScrollView.bottomAnchor).isActive = true
//        p1SV.widthAnchor.constraint(equalTo: p1ScrollView.widthAnchor).isActive = true
//        stackView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor + 50).isActive = true
//        stackView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor).isActive = true

//        stackView.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
//        stackView.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        
        //ui display operations
        p1SV.distribution = .fillEqually
        p1SV.axis = .horizontal
        p1SV.spacing = -60
        
        p2SV.heightAnchor.constraint(equalToConstant: view.frame.height - 775).isActive = true
        p2SV.widthAnchor.constraint(equalToConstant: view.frame.width - 115).isActive = true
        p2SV.distribution = .fillEqually
        p2SV.axis = .horizontal
        p2SV.spacing = -60
        
        p3SV.heightAnchor.constraint(equalToConstant: view.frame.height - 775).isActive = true
        p3SV.widthAnchor.constraint(equalToConstant: view.frame.width - 115).isActive = true
        p3SV.distribution = .fillEqually
        p3SV.axis = .horizontal
        p3SV.spacing = -60
        
        p4SV.heightAnchor.constraint(equalToConstant: view.frame.height - 775).isActive = true
        p4SV.widthAnchor.constraint(equalToConstant: view.frame.width - 115).isActive = true
        p4SV.distribution = .fillEqually
        p4SV.axis = .horizontal
        p4SV.spacing = -60
        
        
//        let iv1 = UIImageView(image: UIImage(named: "2C"))
//        iv1.isUserInteractionEnabled = true
//        iv1.transform = iv1.transform.rotated(by: CGFloat(Double.pi / 2))
//        p2SV.addArrangedSubview(iv21)
        gameNowBegan = true
        //distribute the cards to each player
        allocateCards()
//        setupDisplay()
        removeBooksFromHand()
        asker = players[0]
        setupDisplay()
        
//        startPlay(asker1: players[1], giver1: players[0])
        print(deck.count)

       // print(model.loadModel(fileName: "gofish_2"))
        
    }
    
    func startPlay(asker1:Player, giver1:Player){
        asker1.icon?.setBackgroundImage(UIImage(systemName: "person.circle.fill"), for: .normal)
        giver1.icon?.setBackgroundImage(UIImage(systemName: "person.circle.fill"), for: .normal)
        //check if deck is not empty
        asker = asker1
        giver = giver1
        if(deck.count > 0 && asker.cards.count > 0 && giver.cards.count > 0){
            
            goFishBtnOutlet.isHidden = true
            AskBtnOutlet.isHidden = true
            deckOutletBtn.isUserInteractionEnabled = false
            
            //if asker is user then enable user to select card
            if(asker1.playerIsHuman){
                selectCardLbl.text = "Select Card"
                selectCardLbl.isHidden = false
                for view in stacks[0].subviews{
                    view.isUserInteractionEnabled = true
                }
              
                
            }
            else{
                selectCardLbl.isHidden = true
                for view in stacks[0].subviews{
                    view.isUserInteractionEnabled = false
                }
//                let model = asker.model
//                userAskedCard = asker.cards.randomElement()!
               
//                if (model!.waitingForAction)  && (model!.actionChunk()){
//                    //Checking the state of the model
//                    let state = model!.lastAction(slot: "state")
//                    var userAskedPlayer = ""
//                    if (state != "ask"){
//                        //if (state != "ask"){ should be if (state == "ask"){
//                        //What card is being asked
//
//                        //Who is being asked
//                        userAskedPlayer = model!.lastAction(slot: "opponent_player")!
//                        //Make sure to transform this into proper input for the code
//                        var opponent: Player!
//                        for player in players{
//                            if(userAskedPlayer == player.playerName){
//                                opponent = player
//                            }
//                        }
//                        respondToCardRequest(requestedCard: userAskedCard, asker: asker, giver: opponent)
//
//                    //In the respondToCardRequest, add communication to the models about what happened
//                    }
//                    else if( state == "checking"){
//                        let decision = model!.lastAction(slot: "card_deck")
//                        var resultCheck = ""
//                        //Unsure how active player is specified in this code
//                        resultCheck = checkingHand(requestedCard: decision!, asker: asker)
//                        //resultCheck will either be a string containing a card, or it contains an indicator for failure
//                        if(resultCheck != "failed") {
//                            model!.modifyLastAction(slot: "card_deck", value: String(resultCheck))
//                            model!.modifyLastAction(slot: "state", value: "checking")
//                        }
//                        //If the checking failed, mention this to the model
//                        //If it was asking for a multiple and failed
//                        else if (decision == "multiple"){
//                            model!.modifyLastAction(slot: "state", value: "multiple_failed")
//                        }
//                        //The model was looking through entire hand and reached the end
//                        else{
//                            model!.modifyLastAction(slot: "state", value: "checking_failed")
//                        }
//                    }
//                }
//                asker.model.run()
                
                respondToCardRequest(requestedCard: userAskedCard, asker: asker, giver: giver)
            }
        }
        else{
            //if deck is empty
            endGame()
            
        }
        
    }
    
    func endGame(){
        deckOutletBtn.setImage(UIImage(named: "empty_deck"), for: .normal)
        var message = ""
        //check if user has max points and declare win/lose
        var points:[Int] = []
        for i in players{
            points.append(i.points)
        }
        let index = points.firstIndex(of: points.max()!)
        if(index == 0){
            message = "Congratulations! you win"
        }
        else{
            message = "You loose\n" + players[index!].playerName + " won!"
            
        }
        let alert = UIAlertController(title: "Game Over", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { (action: UIAlertAction!) in
        self.dismiss(animated: false, completion: nil)
        }))
        self.present(alert, animated: true, completion: nil)
    }

    func allocateCards(){
        //distribute cards based on number of players
        var numOfCardsDistrubuted = 5
        if(numOfPlayers == 2){
            numOfCardsDistrubuted = 7
        }
        else if(numOfPlayers == 3){
            numOfCardsDistrubuted = 6
        }
        else if(numOfPlayers == 4){
            numOfCardsDistrubuted = 5
            
        }
        for i in 0..<numOfPlayers{
            let p = Player()
            p.playerName = "player" + String(i)
            
            if(i == 1){
                p.model = Model()
                p.model.loadModel(fileName: "prisoner")
                p.model.run()
                print("initial state is \(p.model.lastAction(slot: "state"))")
               
                // p.model.reset()
              //  p.model.modifyLastAction(slot: "state", value: "first_start")
               
            }
            else if(i == 1){
              //  p.model.loadModel(fileName: "gofish_3")
            }
            else if(i == 2){
             //   p.model.loadModel(fileName: "gofish_4")
            }
            //p.model.reset()
            
            
            players.append(p)
        }
        //unused code
        if(numOfPlayers == 2){
            players[0].nextPlayer = players[1]
            players[1].nextPlayer = players[0]
            
            players[0].icon = P1BtnOutlet
            players[1].icon = P2BtnOutlet
            
            players[0].oponnents = [players[1]]
            players[1].oponnents = [players[0]]
        }
        else if(numOfPlayers == 3){
            P3BtnOutlet.isHidden = false
            player3Lbl.isHidden = false
//            P3BtnOutlet.isUserInteractionEnabled = false
            players[0].nextPlayer = players[1]
            players[1].nextPlayer = players[2]
            players[2].nextPlayer = players[0]
            
            players[0].icon = P1BtnOutlet
            players[1].icon = P2BtnOutlet
            players[2].icon = P3BtnOutlet
            
            players[0].oponnents = [players[1], players[2]]
            players[1].oponnents = [players[0], players[2]]
            players[2].oponnents = [players[0], players[1]]
            
        }
        else if(numOfPlayers == 4){
            P3BtnOutlet.isHidden = false
            player3Lbl.isHidden = false
//            P3BtnOutlet.isUserInteractionEnabled = false
            P4BtnOutlet.isHidden = false
            player4Lbl.isHidden = false
//            P4BtnOutlet.isUserInteractionEnabled = false
            players[0].nextPlayer = players[1]
            players[1].nextPlayer = players[2]
            players[2].nextPlayer = players[3]
            players[3].nextPlayer = players[0]
            
            players[0].icon = P1BtnOutlet
            players[1].icon = P2BtnOutlet
            players[2].icon = P3BtnOutlet
            players[3].icon = P4BtnOutlet
            
            players[0].oponnents = [players[1], players[2], players[3]]
            players[1].oponnents = [players[0], players[2], players[3]]
            players[2].oponnents = [players[0], players[1], players[3]]
            players[3].oponnents = [players[0], players[1], players[2]]
            
        }

        for _ in 0..<numOfCardsDistrubuted{
            for player in players{
                let card = deck.randomElement()!
                deck.remove(at: deck.firstIndex(of: card)!)
                player.cards.append(card)
            }
        }
        players[0].playerName = "User"
        players[0].playerIsHuman = true
        print(players[0].cards)
    }
    
    //fuction to enable user to select player upon selecting card
    @objc func selectCardOnTouch(sender: CustomTapGestureRecognizer) {
        for image in stacks[0].subviews{
            image.backgroundColor = .none
            image.layer.borderWidth = 0
        }
        sender.view?.layer.borderWidth = 4
        sender.view?.layer.borderColor = UIColor.orange.cgColor
//        AskBtnOutlet.isHidden = false
        selectCardLbl.text = "Select Player"
        userAskedCard = sender.userTappedCard!
        for player in plrBtnOutlets{
            player.isUserInteractionEnabled = true
        }
//        P2BtnOutlet.isUserInteractionEnabled = true
//        P3BtnOutlet.isUserInteractionEnabled = true
//        P4BtnOutlet.isUserInteractionEnabled = true
    }

    
    func distributeCardsIfhandEmpty(){
        for player in players{
            if(player.cards.count == 0){
                if(deck.count >= 5){
                    for _ in 0..<5{
                        let randomCard = deck.randomElement()!
                        player.cards.append(randomCard)
                        deck.remove(at: deck.firstIndex(of: randomCard)!)
                    }
                }
            }
        }
    }
    
    func respondToCardRequest(requestedCard:String, asker: Player, giver: Player){
        var temp = giver.cards
        var cardPresent:Bool = false
        var string = ""
        asker.exposedCards.append(requestedCard)
        if(requestedCard.prefix(1).uppercased() == "B"){
            string = asker.playerName + " asking card 10 to " + giver.playerName
        }
        else{
            string = asker.playerName + " asking card " + requestedCard.prefix(1).uppercased()  + " to " + giver.playerName
        }
        
        let alertView = UIAlertController(title: "", message: string, preferredStyle: .alert)
        self.present(alertView, animated: true, completion: nil)
       
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.5){ [self] in
            
            alertView.dismiss(animated: false, completion: nil)
        
        //check if requested card is present in player's hand
        for card in temp{
            let a = String(Array(card)[0])
            if(requestedCard.hasPrefix(a)){
                cardPresent = true
                giver.cards.remove(at: giver.cards.firstIndex(of: card)!)
                asker.cards.append(card)
            }
        }

        temp.removeAll()
        
        //if card present give it to requester
        if(cardPresent){
            var temp2 = giver.exposedCards
            for card in temp2{
                let a = String(Array(card)[0])
                if(requestedCard.hasPrefix(a)){
                    giver.exposedCards.remove(at: giver.exposedCards.firstIndex(of: card)!)
//                    break
                }
            }
            temp2.removeAll()
            var string = ""
            if(requestedCard.prefix(1).uppercased() == "B"){
                string = giver.playerName + " giving card 10 to " + asker.playerName
            }
            else{
                string = giver.playerName + " giving card " + requestedCard.prefix(1).uppercased() + " to " + asker.playerName
            }
            
            let alertView = UIAlertController(title: "", message: string, preferredStyle: .alert)
            self.present(alertView, animated: true, completion: nil)
            asker.icon?.setBackgroundImage(UIImage(systemName: "person.circle"), for: .normal)
            giver.icon?.setBackgroundImage(UIImage(systemName: "person.circle"), for: .normal)
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.5){ [self] in
                
                alertView.dismiss(animated: false, completion: nil)
                
                self.setupDisplay()
                self.removeBooksFromHand()
                self.setupDisplay()
//                self.nextPlayer = asker
                
                
//                return
            
            if(asker.playerIsHuman){
                self.selectCardLbl.text = "Select Card"
                self.selectCardLbl.isHidden = false
                for view in stacks[0].subviews{
                    view.isUserInteractionEnabled = true
                }
            }
            else{
                userAskedCard = getMultipleCard(asker: self.asker)
                if(userAskedCard == ""){
                var foundOpponent = false
                outerLoop: for card in self.asker.cards{
                let a = String(Array(card)[0])
                for i in 0..<asker.oponnents.count{
                    for expCard in self.asker.oponnents[i].exposedCards{
                        if(expCard.hasPrefix(a)){
                            foundOpponent = true
                            self.giver = self.asker.oponnents[i]
                            userAskedCard = expCard
                            break outerLoop
                            }
                        }
                    }
                }
                if(!foundOpponent){
                    self.giver = self.asker.oponnents.randomElement()
                    if(self.giver.cards.count > 0){
                        self.userAskedCard = self.asker.cards.randomElement()!
                    }
                    else{
                        endGame()
                    }
                }
            }
                else{
                    self.giver = self.asker.oponnents.randomElement()
                }
                self.startPlay(asker1: self.asker, giver1: self.giver)
            }
            }
            
        }
        else{
            //enable GoFish button
            asker.icon?.setBackgroundImage(UIImage(systemName: "person.circle"), for: .normal)
            giver.icon?.setBackgroundImage(UIImage(systemName: "person.circle"), for: .normal)
            if(giver.playerIsHuman){
//                DispatchQueue.main.asyncAfter(deadline: .now() + 1.0){
                    self.AskBtnOutlet.isHidden = true
                    self.deckOutletBtn.isUserInteractionEnabled = false
                for view in self.stacks[0].subviews{
                        view.isUserInteractionEnabled = false
                    }
                    self.goFishBtnOutlet.isHidden = false
                self.goFishBtnOutlet.isUserInteractionEnabled = true
//                    return
//                }
            }
            //add card from deck to user's hand
            else if(asker.playerIsHuman){
                let mess = giver.playerName + " says GoFish to " + asker.playerName
                let alertView1 = UIAlertController(title: "", message: mess, preferredStyle: .alert)
                self.present(alertView1, animated: true, completion: nil)
                DispatchQueue.main.asyncAfter(deadline: .now() + 2.5){
                    
                    alertView1.dismiss(animated: false, completion: nil)
                    self.goFishBtnOutlet.isHidden = true
                    self.AskBtnOutlet.isHidden = true
                    self.deckOutletBtn.isUserInteractionEnabled = false
                    for view in self.stacks[0].subviews{
                        view.isUserInteractionEnabled = false
                    }
                    
                    let randomCard = self.deck.randomElement()!
                    self.deckOutletBtn.setImage(UIImage(named: randomCard), for: .normal)
                    self.deck.remove(at: self.deck.firstIndex(of: randomCard)!)
                    asker.cards.append(randomCard)
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.0){ [self] in
                        deckOutletBtn.setImage(UIImage(named: "red_back"), for: .normal)
                        self.setupDisplay()
                        self.removeBooksFromHand()
                        self.setupDisplay()
                        
                        self.asker = self.asker.nextPlayer
                        userAskedCard = getMultipleCard(asker: self.asker)
                        if(userAskedCard == ""){
                        var foundOpponent = false
                        outerLoop: for card in self.asker.cards{
                        let a = String(Array(card)[0])
                        for i in 0..<asker.oponnents.count{
                            for expCard in self.asker.oponnents[i].exposedCards{
                                if(expCard.hasPrefix(a)){
                                    foundOpponent = true
                                    self.giver = self.asker.oponnents[i]
                                    userAskedCard = expCard
                                    break outerLoop
                                    }
                                }
                            }
                        }
                        if(!foundOpponent){
                            self.giver = self.asker.oponnents.randomElement()
                            if(self.giver.cards.count > 0){
                                self.userAskedCard = self.asker.cards.randomElement()!
                            }
                            else{
                                endGame()
                            }
                        }
                    }
                        else{
                            self.giver = self.asker.oponnents.randomElement()
                        }
                        
//                        self.giver = self.asker.oponnents.randomElement()

                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5){
                            startPlay(asker1: self.asker, giver1: self.giver)
                        }
                    }
                }
//                giver.model.modifyLastAction(slot: "card_ask", value: requestedCard.prefix(1).uppercased()) //
//                giver.model.modifyLastAction(slot: "current_player", value: asker.playerName) //whoever has the turn right now
//                giver.model.modifyLastAction(slot: "state", value: "start")
                
            }
            else{
                let mess = giver.playerName + " says GoFish to " + asker.playerName
                let alertView1 = UIAlertController(title: "", message: mess, preferredStyle: .alert)
                self.present(alertView1, animated: true, completion: nil)
                DispatchQueue.main.asyncAfter(deadline: .now() + 2.5){
                    
                    alertView1.dismiss(animated: false, completion: nil)
                let randomCard = deck.randomElement()!
                deck.remove(at: deck.firstIndex(of: randomCard)!)
                //add card to player's hand
                asker.cards.append(randomCard)
                    
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.0){ [self] in
                        deckOutletBtn.setImage(UIImage(named: "red_back"), for: .normal)
                        self.setupDisplay()
                        self.removeBooksFromHand()
                        self.setupDisplay()
                    
                self.asker = self.asker.nextPlayer
                        userAskedCard = getMultipleCard(asker: self.asker)
                    if(userAskedCard == ""){
                    var foundOpponent = false
                    outerLoop: for card in self.asker.cards{
                    let a = String(Array(card)[0])
                    for i in 0..<asker.oponnents.count{
                        for expCard in self.asker.oponnents[i].exposedCards{
                            if(expCard.hasPrefix(a)){
                                foundOpponent = true
                                self.giver = self.asker.oponnents[i]
                                userAskedCard = expCard
                                break outerLoop
                                }
                            }
                        }
                    }
                    if(!foundOpponent){
                        self.giver = self.asker.oponnents.randomElement()
                        if(self.giver.cards.count > 0){
                            self.userAskedCard = self.asker.cards.randomElement()!
                        }
                        else{
                            endGame()
                        }
                    }
                }
                    else{
                        self.giver = self.asker.oponnents.randomElement()
                    }
                    
//                self.giver = self.asker.oponnents.randomElement()
                startPlay(asker1: self.asker, giver1: self.giver)
                }
            }
            }
        }
        }
    }
    
    func pickFromDeck(player:Player){
        if(deck.count > 0){
            let randomCard = deck.randomElement()!
            deckOutletBtn.setImage(UIImage(named: randomCard), for: .normal)
            deck.remove(at: deck.firstIndex(of: randomCard)!)
            player.cards.append(randomCard)
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5){
                self.deckOutletBtn.setImage(UIImage(named: "red_back"), for: .normal)
                self.setupDisplay()
                
            }
            
        }
    }
    //function to arrange cards in hand in ascending order
    func sortHand(hand:[String]) -> [String]{
        let sorterdHand = hand.sorted { $0.compare($1) == ComparisonResult.orderedAscending }
        return sorterdHand
    }
    //remove set of 4 cards from hand if set present
    func removeBooksFromHand(){
        for player in players{
            countCardsInHand(player: player)
            let temp = player.cards
            if(player.count2 == 4){
                for card in temp{
                    if(card.hasPrefix("2")){
                        player.cards.remove(at: player.cards.firstIndex(of: card)!)
                    }
                }
                player.points += 1
            }
            if(player.count3 == 4){
                for card in temp{
                    if(card.hasPrefix("3")){
                        player.cards.remove(at: player.cards.firstIndex(of: card)!)
                    }
                }
                player.points += 1
            }
            if(player.count4 == 4){
                for card in temp{
                    if(card.hasPrefix("4")){
                        player.cards.remove(at: player.cards.firstIndex(of: card)!)
                    }
                }
                player.points += 1
            }
            if(player.count5 == 4){
                for card in temp{
                    if(card.hasPrefix("5")){
                        player.cards.remove(at: player.cards.firstIndex(of: card)!)
                    }
                }
                player.points += 1
            }
            if(player.count6 == 4){
                for card in temp{
                    if(card.hasPrefix("6")){
                        player.cards.remove(at: player.cards.firstIndex(of: card)!)
                    }
                }
                player.points += 1
            }
            if(player.count7 == 4){
                for card in temp{
                    if(card.hasPrefix("7")){
                        player.cards.remove(at: player.cards.firstIndex(of: card)!)
                    }
                }
                player.points += 1
            }
            if(player.count8 == 4){
                for card in temp{
                    if(card.hasPrefix("8")){
                        player.cards.remove(at: player.cards.firstIndex(of: card)!)
                    }
                }
                player.points += 1
            }
            if(player.count9 == 4){
                for card in temp{
                    if(card.hasPrefix("9")){
                        player.cards.remove(at: player.cards.firstIndex(of: card)!)
                    }
                }
                player.points += 1
            }
            if(player.count10 == 4){
                for card in temp{
                    if(card.hasPrefix("B")){
                        player.cards.remove(at: player.cards.firstIndex(of: card)!)
                    }
                }
                player.points += 1
            }
            if(player.countA == 4){
                for card in temp{
                    if(card.hasPrefix("a")){
                        player.cards.remove(at: player.cards.firstIndex(of: card)!)
                    }
                }
                player.points += 1
            }
            if(player.countK == 4){
                for card in temp{
                    if(card.hasPrefix("k")){
                        player.cards.remove(at: player.cards.firstIndex(of: card)!)
                    }
                }
                player.points += 1
            }
            if(player.countQ == 4){
                for card in temp{
                    if(card.hasPrefix("q")){
                        player.cards.remove(at: player.cards.firstIndex(of: card)!)
                    }
                }
                player.points += 1
            }
            if(player.countJ == 4){
                for card in temp{
                    if(card.hasPrefix("j")){
                        player.cards.remove(at: player.cards.firstIndex(of: card)!)
                    }
                }
                player.points += 1
            }
        }
        
        for player in 0..<players.count{
            pointsLbls[player].isHidden = false
            pointsLbls[player].text = String(players[player].points)
        }
    }
    //count the number of each Number/Letter cards present in hand
    func countCardsInHand(player:Player){
        player.count2 = 0
        player.count3 = 0
        player.count4 = 0
        player.count5 = 0
        player.count6 = 0
        player.count7 = 0
        player.count8 = 0
        player.count9 = 0
        player.count10 = 0
        player.countK = 0
        player.countQ = 0
        player.countJ = 0
        player.countA = 0
        
        for card in player.cards{
            if(card.hasPrefix("2")){
                player.count2 += 1
            }
            else if(card.hasPrefix("3")){
                player.count3 += 1
            }
            else if(card.hasPrefix("4")){
                player.count4 += 1
            }
            else if(card.hasPrefix("5")){
                player.count5 += 1
            }
            else if(card.hasPrefix("6")){
                player.count6 += 1
            }
            else if(card.hasPrefix("7")){
                player.count7 += 1
            }
            else if(card.hasPrefix("8")){
                player.count8 += 1
            }
            else if(card.hasPrefix("9")){
                player.count9 += 1
            }
            else if(card.hasPrefix("B")){
                player.count10 += 1
            }
            else if(card.hasPrefix("a")){
                player.countA += 1
            }
            else if(card.hasPrefix("k")){
                player.countK += 1
            }
            else if(card.hasPrefix("q")){
                player.countQ += 1
            }
            else if(card.hasPrefix("j")){
                player.countJ += 1
            }
        }
    }
    
    func getMultipleCard(asker:Player) -> String{
        var multilpleCard:String = ""
        if(asker.count2 == 3){
            multilpleCard = "2S"
        }
        else if(asker.count3 == 3){
            multilpleCard = "3S"
        }
        else if(asker.count4 == 3){
            multilpleCard = "4S"
        }
        else if(asker.count5 == 3){
            multilpleCard = "5S"
        }
        else if(asker.count6 == 3){
            multilpleCard = "6S"
        }
        else if(asker.count7 == 3){
            multilpleCard = "7S"
        }
        else if(asker.count8 == 3){
            multilpleCard = "8S"
        }
        else if(asker.count9 == 3){
            multilpleCard = "9S"
        }
        else if(asker.count10 == 3){
            multilpleCard = "BS"
        }
        else if(asker.countK == 3){
            multilpleCard = "kS"
        }
        else if(asker.countQ == 3){
            multilpleCard = "qS"
        }
        else if(asker.countJ == 3){
            multilpleCard = "jS"
        }
        else if(asker.countA == 3){
            multilpleCard = "aS"
        }
        return multilpleCard
    }
    
    //funcrtion to setup ui display
    
    func setupDisplay(){
        stacks[0].subviews.forEach({ $0.removeFromSuperview() })
        players[0].cards = sortHand(hand: players[0].cards)
        for player in players{
            player.icon?.setBackgroundImage(UIImage(systemName: "person.circle"), for: .normal)
        }
        asker.icon?.setBackgroundImage(UIImage(systemName: "person.circle.fill"), for: .normal)

//
//        }
        for card in players[0].cards{
            let iv = UIImageView(image: UIImage(named: card))
//            iv.transform = iv.transform.rotated(by: CGFloat(Double.pi))
            
            if(asker != nil && asker.playerIsHuman){
                for i in 1..<plrBtnOutlets.count{
                    plrBtnOutlets[i].isUserInteractionEnabled = false
                }
                iv.isUserInteractionEnabled = true
            }
            else{
                iv.isUserInteractionEnabled = false
            }
            
            let tap = CustomTapGestureRecognizer(target: self, action: #selector(selectCardOnTouch))
            tap.userTappedCard = card
            iv.addGestureRecognizer(tap)
            stacks[0].addArrangedSubview(iv)
//            iv.heightAnchor.constraint(equalTo: p1SV.widthAnchor).isActive = true
        }
        for stack in 1..<numOfPlayers{
            players[stack].cards = sortHand(hand: players[stack].cards)
//            countCardsInHand(player: players[stack])
            stacks[stack].subviews.forEach({ $0.removeFromSuperview() })
            for card in players[stack].cards{
                let iv = UIImageView(image: UIImage(named: card))
//                let iv = UIImageView(image: UIImage(named: card))
//                iv.transform = iv.transform.rotated(by: CGFloat(Double.pi))
                stacks[stack].addArrangedSubview(iv)
            }
        }
        deckCountLbl.text = String(deck.count) + " remaining"
        for player in players{
            if(player.cards.count == 0){
                player.isOutOfGame = true
            }
        }
    }
    
//    func nextPlayer(){
//        for i in 0..<players.count{
//            if(players[i].isOutOfGame){
//
//            }
//        }
//    }
    
    func checkingHand(requestedCard:String, asker:Player) -> String {
        var result: String = ""
        //check if model wants first card
        if(requestedCard == "first"){
            //send first card from hand
            result  = asker.cards[0]
        }
        //check if model wants a card which is multiple
        else if(requestedCard == "multiple"){
            //check which card is multiple and return that card name
            if(asker.countQ > 1){
                result = "qC"
            }
            else if(asker.countK > 1){
                result = "kC"
            }
            else if(asker.countJ > 1){
                result = "jC"
            }
            else if(asker.countA > 1){
                result = "aC"
            }
            else if(asker.count2 > 1){
                result = "2H"
            }else if(asker.count3 > 1){
                result = "3H"
            }
            else if(asker.count4 > 1){
                result = "4H"
            }
            else if(asker.count5 > 1){
                result = "5H"
            }
            else if(asker.count6 > 1){
                result = "6H"
            }
            else if(asker.count7 > 1){
                result = "7H"
            }
            else if(asker.count8 > 1){
                result = "8H"
            }
            else if(asker.count9 > 1){
                result = "9H"
            }
            else if(asker.count10 > 1){
                result = "10H"
            }
            else{
                result = "multiple_failed"
            }
        }
        else{
            var z:Int = -1
            result = "failed"
            //check if the card given by model is present in hand
            let reqCardPrefix = String(Array(requestedCard)[0])
            for i in 0..<asker.cards.count{
                let a = String(Array(asker.cards[i])[0])
                if(requestedCard.hasPrefix(a)){
                    z = i
                }
            }
            //if card present
            if(z > -1){
                
                if(z+1 <= asker.cards.count){
                    z += 1
                    //check if card next to requested card is same else increment it and repeat this twice if consiquitive card is same
                    //return failed if card is part of end of hand
                    if(asker.cards[z].hasPrefix(reqCardPrefix)){
                        if(z+1 <= asker.cards.count){
                            z += 1
                            if(asker.cards[z].hasPrefix(reqCardPrefix)){
                                if(z+1 <= asker.cards.count){
                                    z += 1
                                    result = asker.cards[z]
                                }
                                else{
                                    result = "failed"
                                }
                            }
                        }
                        else{
                            result = "failed"
                        }
                    }
                }
                else{
                    result = "failed"
                }
            }
        }
        return result
    }
}
class CustomTapGestureRecognizer: UITapGestureRecognizer {
    var userTappedCard: String?
}

